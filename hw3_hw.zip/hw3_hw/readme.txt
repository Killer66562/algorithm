原始碼部分
hw3.cpp交上去時是讀cost239

二進制檔部分
hw3_*都是在linux上用g++編譯的
使用-O0和-std=c++11